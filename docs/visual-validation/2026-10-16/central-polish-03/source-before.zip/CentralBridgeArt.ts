import {
  BufferAttribute, BufferGeometry, DoubleSide, Group, Mesh, MeshBasicMaterial, NearestFilter,
  PlaneGeometry, SRGBColorSpace, TextureLoader, type Texture,
} from 'three';
import groundUrl from '../../assets/map-modules/howling-central-v1/runtime/ground.png?url';
import snowUrl from '../../assets/map-modules/howling-central-v1/runtime/snow.png?url';
import railUrl from '../../assets/map-modules/howling-central-v1/runtime/rail.png?url';
import archUrl from '../../assets/map-modules/howling-central-v1/runtime/arch.png?url';
import depthUrl from '../../assets/map-modules/howling-central-v1/runtime/depth.png?url';
import fireUrl from '../../assets/map-modules/howling-central-v1/runtime/fire.png?url';
import assetRecords from '../../assets/map-modules/howling-central-v1/manifest.json';
import { BRIDGE, bridgePoint } from '../game/Bridge';
import { unproject } from '../../assets/map-studies/howling-abyss-v1/geometry';
import type { Point } from '../game/types';
import { toThree, type ThreeCamera } from './Coordinates';
import { S01_TORCHES, firePulse } from './S01Look';
import { disposeSceneResources } from './SceneResources';
import { CENTRAL_ARCHES, CENTRAL_BRIDGE as LAYOUT, CENTRAL_RAILS } from './CentralBridgeLayout';

/** Top-view terrain is projected once; elevation assets are placed in vertical world planes. */
export function bridgeArtQuad(minU: number, maxU: number, minV: number, maxV: number, y: number, flipV = false): BufferGeometry {
  const points = [[minU, minV], [maxU, minV], [maxU, maxV], [minU, maxV]].map(([u, v]) => toThree(bridgePoint(u, v), y));
  const geometry = new BufferGeometry();
  geometry.setAttribute('position', new BufferAttribute(new Float32Array(points.flatMap(p => [p.x, p.y, p.z])), 3));
  geometry.setAttribute('uv', new BufferAttribute(new Float32Array(flipV ? [0, 0, 1, 0, 1, 1, 0, 1] : [0, 1, 1, 1, 1, 0, 0, 0]), 2));
  geometry.setIndex([0, 2, 1, 0, 3, 2]); geometry.computeVertexNormals(); return geometry;
}
function elevationQuad(start: number, end: number, v: number, bottom: number, top: number): BufferGeometry {
  const a = bridgePoint(start, v), b = bridgePoint(end, v);
  const points = [toThree(a, bottom), toThree(b, bottom), toThree(b, top), toThree(a, top)];
  const geometry = new BufferGeometry();
  geometry.setAttribute('position', new BufferAttribute(new Float32Array(points.flatMap(p => [p.x, p.y, p.z])), 3));
  geometry.setAttribute('uv', new BufferAttribute(new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), 2));
  geometry.setIndex([0, 1, 2, 0, 2, 3]); geometry.computeVertexNormals(); return geometry;
}

export class CentralBridgeArt {
  readonly group = new Group();
  readonly errors: string[] = [];
  private readonly curtains: { material: MeshBasicMaterial; start: number; end: number; opacity: number }[] = [];
  private lastTime = 0;
  private disposed = false;
  private readonly loaded = new Set<Texture>();
  private readonly braziers: Mesh<PlaneGeometry, MeshBasicMaterial>[] = [];
  constructor() {
    this.group.name = 'Howling central · layered production candidate 01';
    const loader = new TextureLoader();
    const load = (url: string): Texture => {
      const texture = loader.load(url, ready => { if (!this.disposed) this.loaded.add(ready); }, undefined, () => { if (!this.disposed) this.errors.push(url); });
      texture.colorSpace = SRGBColorSpace; texture.magFilter = texture.minFilter = NearestFilter;
      texture.generateMipmaps = false; return texture;
    };
    const maps = { ground: load(groundUrl), snow: load(snowUrl), rail: load(railUrl), arch: load(archUrl), depth: load(depthUrl), fire: load(fireUrl) };
    const material = (map: Texture, cutout = false) => new MeshBasicMaterial({
      map, toneMapped: false, side: DoubleSide, alphaTest: cutout ? 0.35 : 0, fog: false,
    });
    const cropUV = <T extends BufferGeometry>(geometry: T, kind: 'rail' | 'arch' | 'snow' | 'fire', mirror = false): T => {
      const record = assetRecords.find(item => item.id === `howling-central-${kind}-v1`)!;
      const [left, top, right, bottom] = record.runtimeBounds, [width, height] = record.size;
      const uv = geometry.getAttribute('uv');
      for (let i = 0; i < uv.count; i++) uv.setXY(i, (left + (mirror ? 1 - uv.getX(i) : uv.getX(i)) * (right - left)) / width, 1 - bottom / height + uv.getY(i) * (bottom - top) / height);
      return geometry;
    };
    const ground = new Mesh(bridgeArtQuad(LAYOUT.minU, LAYOUT.maxU, -LAYOUT.halfWidth, LAYOUT.halfWidth, LAYOUT.groundY), material(maps.ground));
    ground.name = 'central-ground'; this.group.add(ground);
    const snowMaterial = material(maps.snow, true);
    for (const side of [-1, 1]) for (let i = 0; i < 3; i++) {
      const start = LAYOUT.minU + i * 56;
      const snow = new Mesh(cropUV(bridgeArtQuad(start, start + 56, side < 0 ? -112 : 58, side < 0 ? -58 : 112, LAYOUT.snowY, side > 0), 'snow', i % 2 === 1), snowMaterial);
      snow.name = `snow-fringe-${side}-${i}`; this.group.add(snow);
    }
    for (const pose of CENTRAL_RAILS) {
      // Independent foreground materials allow local fading without fading the floor or every wall.
      const own = material(maps.rail, true);
      const mesh = new Mesh(cropUV(elevationQuad(pose.startU, pose.endU, pose.v, 0, LAYOUT.railHeight), 'rail'), own);
      mesh.name = pose.foreground ? 'near-parapet' : 'far-parapet'; this.group.add(mesh);
      if (pose.foreground) this.curtains.push({ material: own, start: pose.startU, end: pose.endU, opacity: 1 });
    }
    const archMaterial = material(maps.arch, true);
    for (const pose of CENTRAL_ARCHES) {
      const mesh = new Mesh(cropUV(elevationQuad(pose.startU, pose.endU, pose.v, -LAYOUT.archHeight, -4), 'arch'), archMaterial);
      mesh.name = 'bridge-support-arch'; this.group.add(mesh);
    }
    for (const source of S01_TORCHES) {
      const [u] = unproject(BRIDGE, source.x, source.y);
      if (u < LAYOUT.minU || u > LAYOUT.maxU) continue;
      const geometry = cropUV(new PlaneGeometry(38, 54).translate(0, 27, 0), 'fire');
      const mesh = new Mesh(geometry, material(maps.fire, true));
      mesh.name = 'painted-brazier'; mesh.position.copy(toThree(source, 42)); mesh.userData.phase = source.phase;
      this.braziers.push(mesh); this.group.add(mesh);
    }
    const backdrop = new Mesh(new PlaneGeometry(3400, 1900), material(maps.depth));
    backdrop.name = 'abyss-backdrop'; backdrop.position.set(0, -2180, -1250); this.group.add(backdrop);
    for (const child of this.group.children) child.visible = false;
  }
  update(time: number, actor: Point, camera?: ThreeCamera): void {
    for (const child of this.group.children) {
      const mesh = child as Mesh<BufferGeometry, MeshBasicMaterial>;
      child.visible = !!mesh.material.map && this.loaded.has(mesh.material.map);
    }
    const [u, v] = unproject(BRIDGE, actor.x, actor.y);
    const reset = time < this.lastTime;
    const dt = reset ? 0 : Math.max(0, Math.min(0.1, time - this.lastTime)); this.lastTime = time;
    for (const curtain of this.curtains) {
      if (reset) curtain.opacity = 1;
      const target = v > 64 && v < 120 && u >= curtain.start - 8 && u <= curtain.end + 8 ? 0.4 : 1;
      curtain.opacity += (target - curtain.opacity) * (1 - Math.exp(-14 * dt));
      const fading = curtain.opacity < 0.995;
      if (curtain.material.transparent !== fading) { curtain.material.transparent = fading; curtain.material.needsUpdate = true; }
      curtain.material.opacity = fading ? curtain.opacity : 1; curtain.material.depthWrite = !fading;
      curtain.material.alphaTest = fading ? 0.1 : 0.35;
    }
    for (const brazier of this.braziers) {
      if (camera) brazier.quaternion.copy(camera.camera.quaternion);
      brazier.material.color.setScalar(0.96 + firePulse(time, brazier.userData.phase) * 0.04);
    }
  }
  dispose(): void {
    if (this.disposed) return; this.disposed = true;
    disposeSceneResources(this.group); this.group.removeFromParent(); this.group.clear();
  }
}
