/** Candidate art contract, separate from simulation/collision data. Coordinates are local bridge u/v. */
export const CENTRAL_BRIDGE = {
  minU: -88, maxU: 80, halfWidth: 112, focusU: -4,
  groundY: 0.50, snowY: 0.54, cameraElevation: 60,
  railHeight: 58, archHeight: 140,
} as const;
export const CENTRAL_RAILS = [-1, 1].flatMap(side => Array.from({ length: 6 }, (_, i) => ({
  startU: -88 + i * 28, endU: -88 + (i + 1) * 28, v: side * 110, foreground: side === 1,
})));
export const CENTRAL_ARCHES = [-1, 1].flatMap(side => Array.from({ length: 3 }, (_, i) => ({
  startU: -88 + i * 56, endU: -88 + (i + 1) * 56, v: side * 111,
})));
