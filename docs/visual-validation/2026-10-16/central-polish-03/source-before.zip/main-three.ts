import './render-three/prototype.css';
import { Match } from './game/Match';
import { ABILITIES, HOWLING_MAP } from './game/config';
import { bridgePoint } from './game/Bridge';
import { createCombatPractice } from './game/CombatPractice';
import { ThreeArena } from './render-three/ThreeArena';
import { PrototypeHost } from './presentation/PrototypeHost';
import type { AbilityKey, Point } from './game/types';
import { createS01Match } from './presentation/S01Match';
import { CENTRAL_BRIDGE } from './render-three/CentralBridgeLayout';

function element<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id); if (!node) throw new Error(`Missing ${id}`); return node as T;
}
const viewport = element('viewport'), status = element('status'), error = element('error');
if (!HOWLING_MAP) {
  // Reload with an explicit map selection before importing a different simulation state.
  const url = new URL(location.href); url.searchParams.set('map', 'howling'); location.replace(url);
} else {
  try { boot(); } catch (cause) {
    error.hidden = false; error.textContent = `样板启动失败：${cause instanceof Error ? cause.message : String(cause)}\n原版入口仍可从上方链接打开。`;
  }
}

function boot(): void {
  const scenario = element<HTMLSelectElement>('scenario');
  const view = new ThreeArena(viewport);
  const lookSelect = element<HTMLSelectElement>('presentation');
  if (new URLSearchParams(location.search).get('look') === 'gray') lookSelect.value = 'gray';
  view.presentation = lookSelect.value as 'art' | 'gray';
  const host = new PrototypeHost(() => scenario.value === 'match' ? new Match() : scenario.value === 'central' ? createS01Match(-10) : scenario.value === 'sample' ? createS01Match() : createCombatPractice(), view);
  const abort = new AbortController(), signal = abort.signal;
  let previous = performance.now(), raf = 0, lastStatus = -1, selected: number | null = null;
  const keys = new Set<string>();
  let pointer: Point | null = null;
  const followButton = element<HTMLButtonElement>('follow');
  function syncFollow(): void { followButton.textContent = `跟随英雄：${view.following ? '开' : '关'}`; }
  function targetAim(point: Point): Point | null {
    const actor = host.match.entity(view.pickActor(point));
    return actor && actor.hp > 0 ? { x: actor.x, y: actor.y } : view.ground(point);
  }
  function cast(ability: AbilityKey): void {
    const aim = pointer ? targetAim(pointer) : null;
    if (!aim) { element('selection').textContent = '先将鼠标移到地面或目标，再施放技能。'; return; }
    const accepted = host.command({ kind: 'cast', ability, point: aim });
    element('selection').textContent = `${ability.toUpperCase()}：${accepted ? '已释放' : '检查冷却、目标、击飞或当前动作'}。样板已接入角色 Q/E 动画，完整刀光与特效仍待后续校准。`;
  }
  view.onFrame = ({ match }) => {
    if (performance.now() - lastStatus < 200) return; lastStatus = performance.now();
    const h = match.hero('blue'), target = match.entity(selected);
    const cooldowns = (['q', 'w', 'e', 'r'] as const).map(key => `${key.toUpperCase()} ${Math.max(0, h.abilities[key] - match.time).toFixed(1)}`).join(' / ');
    status.textContent = `${view.presentation === 'art' ? '中央桥段 · 分层美术候选' : 'P1 灰盒'} · ${match.phase} · ${match.time.toFixed(2)}s · HP ${Math.round(h.hp)}/${h.maxHp} · 缩放 ${view.cameraRig.zoom} · ${view.cameraRig.elevation}° · 内部 ${view.renderer.domElement.width}×${view.renderer.domElement.height} · 调用 ${view.renderer.info.render.calls} · 目标 ${target ? `${target.id} HP ${Math.round(target.hp)}` : '无'} · 冷却 ${cooldowns}${view.presentation === 'gray' ? ` · Q 范围 ${ABILITIES.q.range}` : ''}${view.environment.textureErrors.length || view.central.errors.length || view.sprites.errors.length ? ' · 部分素材加载失败，请检查本地服务' : ''}`;
  };
  const listen = <K extends keyof HTMLElementEventMap>(node: HTMLElement, type: K, fn: (event: HTMLElementEventMap[K]) => void) => node.addEventListener(type, fn, { signal });
  listen(viewport, 'contextmenu', event => event.preventDefault());
  listen(viewport, 'pointermove', event => { pointer = { x: event.clientX, y: event.clientY }; view.aim = targetAim(pointer); });
  listen(viewport, 'pointerdown', event => {
    viewport.focus(); pointer = { x: event.clientX, y: event.clientY };
    const id = view.pickActor(pointer), entity = host.match.entity(id);
    if (event.button === 0) { selected = id; view.selectedId = id; }
    if (event.button === 2) {
      if (entity && entity.team === 'red' && entity.hp > 0) host.command({ kind: 'attack', id: entity.id });
      else { const point = view.ground(pointer); if (point) host.command({ kind: 'move', point }); }
    }
  });
  viewport.addEventListener('wheel', event => {
    event.preventDefault(); const levels = [0.6, 1, 1.5];
    const index = levels.indexOf(view.cameraRig.zoom);
    view.cameraRig.setZoom(levels[Math.max(0, Math.min(2, index + (event.deltaY < 0 ? 1 : -1)))]);
  }, { signal, passive: false });
  window.addEventListener('keydown', event => {
    if (event.target instanceof HTMLInputElement || event.target instanceof HTMLSelectElement || event.target instanceof HTMLTextAreaElement) return;
    const key = event.key.toLowerCase();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(key)) event.preventDefault();
    keys.add(key); if (event.repeat) return;
    if (['q', 'w', 'e', 'r'].includes(key)) cast(key as AbilityKey);
    if (key === 's') host.command({ kind: 'stop' });
    if (key === 'escape') host.pause();
    if (key === 'y') { view.following = !view.following; syncFollow(); }
  }, { signal });
  window.addEventListener('keyup', event => keys.delete(event.key.toLowerCase()), { signal });
  const pauseHidden = () => { keys.clear(); if (host.match.phase === 'playing') host.pause(); previous = performance.now(); };
  window.addEventListener('blur', pauseHidden, { signal });
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseHidden(); previous = performance.now(); }, { signal });
  listen(element('pause'), 'click', () => host.pause());
  const restart = () => { host.restart(); selected = null; view.selectedId = null; view.following = true; previous = performance.now(); syncFollow(); };
  listen(element('restart'), 'click', restart); listen(scenario, 'change', restart);
  listen(followButton, 'click', () => { view.following = !view.following; syncFollow(); });
  const look = (point: Point) => { view.following = false; view.cameraRig.lookAt(point); syncFollow(); };
  listen(element('sample'), 'click', () => look(bridgePoint(CENTRAL_BRIDGE.focusU, 0)));
  listen(element('middle'), 'click', () => look(bridgePoint(0, 0)));
  const elevation = element<HTMLSelectElement>('elevation'), texture = element<HTMLSelectElement>('texture');
  listen(elevation, 'change', () => view.cameraRig.setElevation(Number(elevation.value)));
  listen(texture, 'change', () => view.setTexture(Number(texture.value) as 32 | 64));
  listen(lookSelect, 'change', () => {
    view.presentation = lookSelect.value as 'art' | 'gray'; texture.disabled = elevation.disabled = view.presentation === 'art';
    if (view.presentation === 'art') { view.cameraRig.setElevation(CENTRAL_BRIDGE.cameraElevation); elevation.value = String(CENTRAL_BRIDGE.cameraElevation); }
  });
  texture.disabled = view.presentation === 'art';
  elevation.disabled = view.presentation === 'art';
  function frame(now: number): void {
    const dt = Math.min(Math.max(0, now - previous) / 1000, 0.25); previous = now;
    const dx = Number(keys.has('arrowright')) - Number(keys.has('arrowleft'));
    const dy = Number(keys.has('arrowdown')) - Number(keys.has('arrowup'));
    if (dx || dy) { view.pan(dx * 280 * dt, dy * 280 * dt); syncFollow(); }
    if (keys.has(' ')) { view.cameraRig.lookAt(host.match.hero('blue')); }
    // Refresh ground aim after any camera motion; the pointer's client position is unchanged.
    if (pointer) view.aim = targetAim(pointer);
    host.update(dt); raf = requestAnimationFrame(frame);
  }
  raf = requestAnimationFrame(frame);
  const dispose = () => { cancelAnimationFrame(raf); abort.abort(); host.dispose(); };
  window.addEventListener('pagehide', dispose, { once: true, signal });
  if (import.meta.hot) import.meta.hot.dispose(dispose);
}
