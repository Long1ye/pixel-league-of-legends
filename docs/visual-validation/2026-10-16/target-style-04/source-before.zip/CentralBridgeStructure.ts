import {
  AmbientLight, BufferAttribute, BufferGeometry, ConeGeometry, CylinderGeometry, DodecahedronGeometry,
  ExtrudeGeometry, Group, Matrix4, Mesh, MeshBasicMaterial, MeshStandardMaterial,
  Shape, TorusGeometry, Vector3, type Material, type Texture,
} from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { bridgePoint } from '../game/Bridge';
import { toThree } from './Coordinates';
import { CENTRAL_ARCHES, CENTRAL_BRIDGE as LAYOUT, CENTRAL_RAILS } from './CentralBridgeLayout';
import { S01_TORCHES } from './S01Look';

/** Closed, bevelled masonry with a genuinely open arch, including its soffit. */
export function bridgeSupportGeometry(width: number): ExtrudeGeometry {
  const post = 38, spring = -205, radius = width / 2 - post;
  const shape = new Shape();
  shape.moveTo(0, LAYOUT.deckBottom); shape.lineTo(width, LAYOUT.deckBottom);
  shape.lineTo(width, -LAYOUT.archHeight); shape.lineTo(width - post, -LAYOUT.archHeight);
  shape.lineTo(width - post, spring);
  shape.absarc(width / 2, spring, radius, 0, Math.PI, false);
  shape.lineTo(post, -LAYOUT.archHeight); shape.lineTo(0, -LAYOUT.archHeight); shape.closePath();
  return new ExtrudeGeometry(shape, { depth: 40, steps: 1, curveSegments: 18,
    bevelEnabled: true, bevelSize: 2, bevelThickness: 2, bevelSegments: 1 }).translate(0, 0, -20);
}

export interface StructuralCurtain { start: number; end: number; materials: Material[]; opacity: number }
export function createCentralBridgeStructure(stoneMap: Texture): {
  group: Group; curtains: StructuralCurtain[]; flames: Mesh[];
} {
  const group = new Group(); group.name = 'central-solid-architecture';
  // Blue sky bounce reaches the soffits and the camera-facing masonry, rather
  // than letting the directional deck shadow turn an entire facade black.
  group.add(new AmbientLight(0xa6c4dd, 1.3));
  const curtains: StructuralCurtain[] = [], flames: Mesh[] = [];
  const stone = new MeshStandardMaterial({ map: stoneMap, color: 0xc4d4df, roughness: 0.94 });
  const trim = new MeshStandardMaterial({ color: 0x8599ac, roughness: 0.92 });
  const dark = new MeshStandardMaterial({ color: 0x273944, roughness: 1 });
  const snow = new MeshStandardMaterial({ color: 0x9ab6cf, roughness: 0.98 });
  const ice = new MeshStandardMaterial({ color: 0x89b7d0, roughness: 0.35, metalness: 0.12 });
  const batches = new Map<Material, BufferGeometry[]>();
  const add = (geometry: BufferGeometry, material: Material, target = batches) => {
    const list = target.get(material) ?? []; list.push(geometry); target.set(material, list);
  };
  const uv = (geometry: BufferGeometry): BufferGeometry => {
    const p = geometry.getAttribute('position'), n = geometry.getAttribute('normal'), values = new Float32Array(p.count * 2);
    for (let i = 0; i < p.count; i++) {
      values[i * 2] = (Math.abs(n.getX(i)) > 0.6 ? p.getZ(i) : p.getX(i)) / 72;
      values[i * 2 + 1] = (Math.abs(n.getY(i)) > 0.6 ? p.getZ(i) : p.getY(i)) / 72;
    }
    // All batches use the same non-indexed layout, including curved components.
    const result = geometry.index ? geometry.toNonIndexed() : geometry;
    if (result !== geometry) geometry.dispose();
    // Recompute UV after expanding an indexed geometry.
    if (result !== geometry) return uv(result);
    result.setAttribute('uv', new BufferAttribute(values, 2));
    return result;
  };
  const flush = (source: Map<Material, BufferGeometry[]>, parent: Group, name: string) => {
    for (const [material, geometries] of source) {
      const merged = mergeGeometries(geometries, false);
      if (!merged) throw new Error('Cannot batch central masonry');
      const mesh = new Mesh(merged, material); mesh.name = name;
      mesh.castShadow = mesh.receiveShadow = true; parent.add(mesh);
      geometries.forEach(g => g.dispose());
    }
  };
  const along = toThree(bridgePoint(1)).sub(toThree(bridgePoint(0))).normalize();
  const normal = new Vector3(-along.z, 0, along.x);
  const placement = (u: number, v: number) => new Matrix4().makeBasis(along, new Vector3(0, 1, 0), normal).setPosition(toThree(bridgePoint(u, v)));
  const spanLength = (a: number, b: number) => toThree(bridgePoint(b)).distanceTo(toThree(bridgePoint(a)));
  const box = (x: number, y: number, z: number, w: number, h: number, d: number, matrix: Matrix4,
    material: Material, target = batches) => {
    const bevel = Math.min(2.2, h / 5, d / 5), shape = new Shape();
    shape.moveTo(-w / 2 + bevel, -h / 2 + bevel); shape.lineTo(w / 2 - bevel, -h / 2 + bevel);
    shape.lineTo(w / 2 - bevel, h / 2 - bevel); shape.lineTo(-w / 2 + bevel, h / 2 - bevel); shape.closePath();
    const geometry = new ExtrudeGeometry(shape, { depth: d - 2 * bevel, steps: 1,
      bevelEnabled: true, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 1 });
    add(uv(geometry.translate(x, y, z - d / 2 + bevel)).applyMatrix4(matrix), material, target);
  };

  // Solid low walls, broad capstones, buttressed piers and snow with overhang.
  // One separate ownership group per near segment keeps occlusion fading local.
  for (const pose of CENTRAL_RAILS) {
    const target = new Map<Material, BufferGeometry[]>(), parent = new Group();
    parent.name = pose.foreground ? 'near-parapet' : 'far-parapet';
    const ownStone = stone.clone(), ownTrim = trim.clone(), ownSnow = snow.clone(), ownIce = ice.clone();
    const matrix = placement(pose.startU, pose.v), width = spanLength(pose.startU, pose.endU);
    box(width / 2, 32, 0, width - 22, 64, 23, matrix, ownStone, target);
    box(width / 2, 8, 0, width, 16, 32, matrix, ownTrim, target);
    box(width / 2, 68, 0, width - 18, 10, 31, matrix, ownTrim, target);
    box(width / 2, 76, 0, width - 15, 6, 35, matrix, ownSnow, target);
    for (let k = 0; k < 6; k++) {
      add(uv(new DodecahedronGeometry(1, 0).scale(15 + k % 2 * 3, 3.5, 18)
        .translate(15 + k * (width - 30) / 5, 79, k % 2 ? -2 : 2)).applyMatrix4(matrix), ownSnow, target);
    }
    const column = (x: number, ornament: boolean) => {
      box(x, 10, 0, 43, 20, 43, matrix, ownTrim, target);
      box(x, 68, 0, 30, 116, 31, matrix, ownStone, target);
      box(x, 38, 0, 36, 8, 37, matrix, ownTrim, target);
      box(x, 121, 0, 38, 12, 39, matrix, ownTrim, target);
      box(x, 130, 0, 42, 7, 43, matrix, ownSnow, target);
      for (const face of [-1, 1]) {
        // Raised interlaced stone marks are geometry on both sides of a pier.
        for (const y of [62, 82]) {
          const relief = new TorusGeometry(8, 2, 4, 4).rotateZ(Math.PI / 4)
            .translate(x, y, face * 17.5);
          add(uv(relief).applyMatrix4(matrix), ownTrim, target);
        }
      }
      if (ornament) {
        const crystal = new ConeGeometry(10, 36, 5).translate(x, 149, 0);
        add(uv(crystal).applyMatrix4(matrix), ownIce, target);
      }
      for (const offset of [-10, 9]) {
        add(uv(new ConeGeometry(2.6, 18 + Math.abs(offset), 5).rotateZ(Math.PI)
          .translate(x + offset, 116, 22)).applyMatrix4(matrix), ownIce, target);
      }
    };
    column(0, Math.round((pose.startU - LAYOUT.edgeMinU) / 42) % 2 === 0);
    if (pose.endU === LAYOUT.edgeMaxU) column(width, true);
    flush(target, parent, 'solid-parapet-masonry'); group.add(parent);
    if (pose.foreground) curtains.push({ start: pose.startU, end: pose.endU,
      materials: [ownStone, ownTrim, ownSnow, ownIce], opacity: 1 });
  }

  for (const pose of CENTRAL_ARCHES) {
    const width = spanLength(pose.startU, pose.endU), matrix = placement(pose.startU, pose.v);
    add(uv(bridgeSupportGeometry(width)).applyMatrix4(matrix), stone);
    // Individual radial arch stones project out from both faces; the underside
    // is real geometry rather than a painted dark curve.
    const radius = width / 2 - 38;
    for (let j = 0; j < 13; j++) {
      const a = j * Math.PI / 13 + 0.009, b = (j + 1) * Math.PI / 13 - 0.009;
      const wedge = new Shape();
      wedge.absarc(width / 2, -205, radius + 27, a, b, false);
      wedge.absarc(width / 2, -205, radius + 2, b, a, true); wedge.closePath();
      add(uv(new ExtrudeGeometry(wedge, { depth: 47, bevelEnabled: false, curveSegments: 3 })
        .translate(0, 0, -23.5)).applyMatrix4(matrix), j % 3 === 0 ? trim : stone);
    }
    const buttress = (x: number) => {
      box(x, -258, 0, 48, 238, 58, matrix, stone);
      box(x, -355, 0, 66, 32, 75, matrix, trim);
      box(x, -174, 0, 57, 13, 67, matrix, trim);
      box(x, -164, 0, 61, 7, 71, matrix, snow);
      box(x, -22, 0, 48, 24, 56, matrix, trim);
    };
    buttress(0); if (pose.endU === LAYOUT.edgeMaxU) buttress(width);
    box(width / 2, -8, 0, width, 16, 48, matrix, trim);
  }
  // Volumetric shoulder snow sits above the surface overlay.
  for (const side of [-1, 1]) for (let i = 0; i < 20; i++) {
    const u = LAYOUT.edgeMinU + 8 + i * 16.5;
    const p = toThree(bridgePoint(u, side * (99 + i % 3)), 2);
    add(uv(new DodecahedronGeometry(1, 0).scale(20 + i % 4 * 2, 3 + i % 3, 12)
      .translate(p.x, p.y, p.z)), snow);
  }
  // Real distant columns provide parallax and silhouette, with fog separating
  // them from the bridge. No full-scene panorama follows the camera.
  const cliff = new MeshStandardMaterial({ color: 0x506c83, roughness: 1 });
  for (const side of [-1, 1]) for (let i = 0; i < 18; i++) {
    const p = toThree(bridgePoint(-330 + i * 41, side * (235 + i % 4 * 105)), -720 - i % 3 * 150);
    const height = 680 + i % 5 * 95, radius = 60 + i % 4 * 19;
    add(uv(new CylinderGeometry(radius * 0.53, radius, height, 7).translate(p.x, p.y, p.z)), cliff);
    add(uv(new ConeGeometry(radius * 0.58, 15, 7).translate(p.x, p.y + height / 2 + 3, p.z)), snow);
  }
  // Braziers are bowls and stone pedestals; only the emissive flame is unlit.
  for (const source of S01_TORCHES) {
    const u = source.phase; if (u < LAYOUT.edgeMinU || u > LAYOUT.edgeMaxU) continue;
    const p = toThree(source), matrix = new Matrix4().makeTranslation(p.x, 0, p.z);
    box(0, 8, 0, 36, 16, 36, matrix, trim);
    box(0, 24, 0, 27, 20, 27, matrix, stone);
    add(uv(new CylinderGeometry(22, 13, 16, 10).translate(0, 39, 0)).applyMatrix4(matrix), trim);
    add(uv(new CylinderGeometry(18, 15, 2, 10).translate(0, 47.5, 0)).applyMatrix4(matrix), dark);
    add(uv(new TorusGeometry(20, 2.5, 4, 10).rotateX(Math.PI / 2).translate(0, 48, 0)).applyMatrix4(matrix), trim);
    const flame = new Mesh(new ConeGeometry(10, 28, 5), new MeshBasicMaterial({ color: 0xffb34e, toneMapped: false }));
    flame.position.set(p.x, 61, p.z); flame.userData.phase = source.phase;
    flame.name = 'volumetric-brazier-flame'; flames.push(flame); group.add(flame);
  }
  flush(batches, group, 'solid-bridge-architecture');
  // The prototype owns every geometry and material through this tree.
  // Base templates were cloned for wall segments, so dispose the unused originals
  // only if they are not used by the static batches.
  ice.dispose();
  return { group, curtains, flames };
}
