import { OrthographicCamera, Plane, Raycaster, Vector2, Vector3 } from 'three';
import type { Point } from '../game/types';
import { BRIDGE_WORLD } from '../game/Bridge';

// The simulation already contains the bridge's authoring projection. Map it once,
// isometrically, to X/Z. Camera foreshortening belongs only to presentation.
export const WORLD_ORIGIN = { x: BRIDGE_WORLD.width / 2, y: BRIDGE_WORLD.height / 2 };
export function toThree(point: Point, height = 0): Vector3 {
  return new Vector3(point.x - WORLD_ORIGIN.x, height, point.y - WORLD_ORIGIN.y);
}
export function toSimulation(point: Vector3): Point {
  return { x: point.x + WORLD_ORIGIN.x, y: point.z + WORLD_ORIGIN.y };
}
export interface ViewSize { width: number; height: number }
export interface ViewRect extends ViewSize { left: number; top: number }
export const CAMERA_CANDIDATE = { elevation: 60, referenceHeight: 270, distance: 5000 } as const;

export class ThreeCamera {
  readonly camera = new OrthographicCamera(-400, 400, 225, -225, 1, 12000);
  readonly focus: Point = { ...WORLD_ORIGIN };
  size: ViewSize = { width: 1280, height: 720 };
  zoom = 0.6;
  elevation = Number(CAMERA_CANDIDATE.elevation);
  private readonly raycaster = new Raycaster();
  private readonly ground = new Plane(new Vector3(0, 1, 0), 0);

  constructor() { this.update(); }
  resize(width: number, height: number): void {
    if (!(width > 0 && height > 0 && Number.isFinite(width) && Number.isFinite(height))) throw new RangeError('Invalid viewport');
    this.size = { width, height }; this.update();
  }
  lookAt(point: Point): void { Object.assign(this.focus, point); this.update(); }
  setZoom(value: number): void {
    if (!(value > 0 && Number.isFinite(value))) throw new RangeError('Invalid zoom');
    this.zoom = value; this.update();
  }
  setElevation(degrees: number): void {
    if (![45, 60, 75].includes(degrees)) throw new RangeError('Unsupported camera candidate');
    this.elevation = degrees; this.update();
  }
  project(point: Point, height = 0): Point {
    const projected = toThree(point, height).project(this.camera);
    return { x: (projected.x + 1) * this.size.width / 2, y: (1 - projected.y) * this.size.height / 2 };
  }
  pick(client: Point, rect: ViewRect): Point | null {
    if (!(rect.width > 0 && rect.height > 0)) return null;
    const u = (client.x - rect.left) / rect.width, v = (client.y - rect.top) / rect.height;
    if (u < 0 || u > 1 || v < 0 || v > 1) return null;
    this.raycaster.setFromCamera(new Vector2(u * 2 - 1, 1 - v * 2), this.camera);
    const hit = this.raycaster.ray.intersectPlane(this.ground, new Vector3());
    return hit ? toSimulation(hit) : null;
  }
  /** Screen heading for future eight-direction sprite selection; never changes simulation facing. */
  screenHeading(point: Point, facing: number): number {
    const a = this.project(point), b = this.project({ x: point.x + Math.cos(facing), y: point.y + Math.sin(facing) });
    return Math.atan2(b.y - a.y, b.x - a.x);
  }
  private update(): void {
    const halfHeight = CAMERA_CANDIDATE.referenceHeight / this.zoom / 2;
    const halfWidth = halfHeight * this.size.width / this.size.height;
    Object.assign(this.camera, { left: -halfWidth, right: halfWidth, top: halfHeight, bottom: -halfHeight });
    const target = toThree(this.focus), angle = this.elevation * Math.PI / 180;
    this.camera.position.copy(target).add(new Vector3(0, Math.sin(angle), Math.cos(angle)).multiplyScalar(CAMERA_CANDIDATE.distance));
    this.camera.lookAt(target); this.camera.updateProjectionMatrix(); this.camera.updateMatrixWorld(true);
  }
}
