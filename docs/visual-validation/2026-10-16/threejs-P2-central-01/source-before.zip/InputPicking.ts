import { Raycaster, Vector2, type Object3D } from 'three';
import type { Point } from '../game/types';
import type { ThreeCamera, ViewRect } from './Coordinates';

/** Pick only explicitly supplied entity proxies; scenery cannot capture commands. */
export function pickActorId(view: ThreeCamera, rect: ViewRect, client: Point, actors: Object3D[], raycaster = new Raycaster()): number | null {
  if (!(rect.width > 0 && rect.height > 0)) return null;
  const u = (client.x - rect.left) / rect.width, v = (client.y - rect.top) / rect.height;
  if (u < 0 || u > 1 || v < 0 || v > 1) return null;
  raycaster.setFromCamera(new Vector2(u * 2 - 1, 1 - v * 2), view.camera);
  for (const actor of actors) actor.updateWorldMatrix(true, false);
  const hit = raycaster.intersectObjects(actors, false)[0];
  return hit && Number.isSafeInteger(hit.object.userData.entityId) ? hit.object.userData.entityId : null;
}
