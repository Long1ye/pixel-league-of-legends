import {
  AmbientLight, BufferGeometry, ConeGeometry, CylinderGeometry, DirectionalLight,
  Group, Line, LineBasicMaterial, Mesh, MeshLambertMaterial, Raycaster,
  Scene, SphereGeometry, Vector3, WebGLRenderer, Fog, BasicShadowMap, ACESFilmicToneMapping, NoToneMapping, SRGBColorSpace,
} from 'three';
import type { PrototypeFrame, PrototypeView } from '../presentation/PrototypeHost';
import type { Entity, Point } from '../game/types';
import { ABILITIES } from '../game/config';
import { UNIT_METRICS } from '../game/UnitMetrics';
import { YASUO_Q_CAST_SECONDS } from '../game/YasuoQ';
import { wallEnds } from '../game/WindWall';
import { createBridgeBlockout, pixelGrid } from './BridgeBlockout';
import { ThreeCamera, toThree } from './Coordinates';
import { pickActorId } from './InputPicking';
import { disposeSceneResources } from './SceneResources';
import { S01Environment } from './S01Environment';
import { ActorSprites } from './ActorSprites';

/** P2 art sample with a retained P1 diagnostic mode. Visual approval is separate. */
export class ThreeArena implements PrototypeView {
  readonly cameraRig = new ThreeCamera();
  readonly renderer: WebGLRenderer;
  readonly scene = new Scene();
  readonly blockout = createBridgeBlockout();
  readonly environment = new S01Environment();
  readonly sprites = new ActorSprites();
  presentation: 'art' | 'gray' = 'art';
  following = true;
  selectedId: number | null = null;
  aim: Point | null = null;
  onFrame?: (value: PrototypeFrame) => void;
  private readonly actors = new Map<number, Mesh>();
  private readonly dynamic = new Group();
  private readonly hints = new Group();
  private readonly diagnosticLights = new Group();
  private readonly raycaster = new Raycaster();
  private readonly bodyGeometry = new CylinderGeometry(1, 1, 1, 8);
  private readonly shotGeometry = new SphereGeometry(3, 6, 4);
  private readonly blue = new MeshLambertMaterial({ color: 0x80c9dd });
  private readonly red = new MeshLambertMaterial({ color: 0xd88d8c });
  private readonly hintMaterial = new LineBasicMaterial({ color: 0xe0c184 });
  private readonly wallMaterial = new LineBasicMaterial({ color: 0xaeddf1 });
  private readonly selection: Line;
  private readonly range: Line;
  private readonly aimLine: Line;
  private disposed = false;
  private currentMatch: PrototypeFrame['match'] | null = null;
  private transientResources: { dispose(): void }[] = [];
  private readonly observer: ResizeObserver;

  constructor(private readonly container: HTMLElement) {
    this.renderer = new WebGLRenderer({ antialias: false, alpha: false });
    this.renderer.setPixelRatio(1); this.renderer.setClearColor(0x111b29);
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = BasicShadowMap;
    this.renderer.outputColorSpace = SRGBColorSpace; this.renderer.toneMappingExposure = 1.05;
    this.renderer.domElement.setAttribute('aria-label', 'Three.js S01 画面样板画布');
    container.append(this.renderer.domElement);
    this.diagnosticLights.add(new AmbientLight(0xc3d4e5, 1.1));
    const sun = new DirectionalLight(0xffe4c2, 2.0); sun.position.set(-300, 600, 250); this.diagnosticLights.add(sun);
    this.scene.add(this.blockout.group, this.dynamic, this.hints, this.diagnosticLights, this.environment.group, this.sprites.group);
    const circle = Array.from({ length: 65 }, (_, i) => ({ x: Math.cos(i * Math.PI / 32), y: Math.sin(i * Math.PI / 32) }));
    const circleGeometry = () => new BufferGeometry().setFromPoints(circle.map(p => new Vector3(p.x, 1, p.y)));
    this.selection = new Line(circleGeometry(), this.hintMaterial);
    this.range = new Line(circleGeometry(), this.hintMaterial);
    this.aimLine = new Line(new BufferGeometry().setFromPoints([new Vector3(), new Vector3(1, 0, 0)]), this.hintMaterial);
    this.aimLine.frustumCulled = false; // Endpoints change every frame; no stale bounding sphere.
    this.scene.add(this.selection, this.range, this.aimLine);
    // Forward arrow is a visible diagnostic of each actor's simulation heading.
    this.observer = new ResizeObserver(() => this.resize()); this.observer.observe(container); this.resize();
  }
  resize(): void {
    const width = this.container.clientWidth, height = this.container.clientHeight;
    if (!width || !height || this.disposed) return;
    this.cameraRig.resize(width, height);
    this.renderer.setSize(640, Math.max(1, Math.round(640 * height / width)), false);
  }
  setTexture(size: 32 | 64): void {
    this.blockout.material.map?.dispose(); this.blockout.material.map = pixelGrid(size); this.blockout.material.needsUpdate = true;
  }
  ground(client: Point): Point | null { return this.cameraRig.pick(client, this.renderer.domElement.getBoundingClientRect()); }
  pickActor(client: Point): number | null {
    const rect = this.renderer.domElement.getBoundingClientRect();
    return pickActorId(this.cameraRig, rect, client, [...this.actors.values()], this.raycaster);
  }
  pan(dx: number, dy: number): void {
    this.following = false;
    const rect = this.renderer.domElement.getBoundingClientRect();
    const center = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    const from = this.cameraRig.pick(center, rect), to = this.cameraRig.pick({ x: center.x + dx, y: center.y + dy }, rect);
    if (from && to) this.cameraRig.lookAt({ x: this.cameraRig.focus.x + to.x - from.x, y: this.cameraRig.focus.y + to.y - from.y });
  }
  frame(value: PrototypeFrame): void {
    if (this.disposed) return;
    if (this.currentMatch !== value.match) { this.clearActors(); this.sprites.reset(); this.currentMatch = value.match; this.selectedId = null; }
    const { match, positions, alpha } = value;
    const art = this.presentation === 'art';
    this.renderer.toneMapping = art ? ACESFilmicToneMapping : NoToneMapping;
    this.blockout.group.visible = this.diagnosticLights.visible = !art;
    this.environment.group.visible = this.sprites.group.visible = art;
    this.scene.fog = art ? this.sampleFog : null;
    const hero = positions.sample(match.hero('blue'), alpha);
    if (this.following) this.cameraRig.lookAt(hero);
    if (art) {
      this.environment.update(match.time, match.tower('blue').hp > 0, { point: hero, height: UNIT_METRICS.hero.height, camera: this.cameraRig });
      this.sprites.update(match.entities.map(entity => positions.sample(entity, alpha)), match.time, this.cameraRig);
    }
    const active = new Set<number>();
    for (const entity of match.entities) {
      if (entity.hp <= 0) continue;
      active.add(entity.id);
      let mesh = this.actors.get(entity.id);
      const metrics = UNIT_METRICS[entity.kind];
      if (!mesh) {
        mesh = new Mesh(this.bodyGeometry, entity.team === 'blue' ? this.blue : this.red);
        mesh.scale.set(entity.radius, metrics.height, entity.radius); mesh.userData.entityId = entity.id;
        this.actors.set(entity.id, mesh); this.scene.add(mesh);
      }
      const p = positions.sample(entity, alpha);
      const lift = (entity.airborneUntil ?? 0) > match.time ? 30 : 0;
      mesh.position.copy(toThree(p, metrics.height / 2 + lift));
      mesh.visible = !art || (entity.kind === 'tower' ? entity.team !== 'blue' : !this.sprites.hasVisibleBody(entity.id));
    }
    for (const [id, mesh] of this.actors) if (!active.has(id)) { this.scene.remove(mesh); this.actors.delete(id); }
    const selected = match.entity(this.selectedId);
    this.selection.visible = !!selected && selected.hp > 0;
    if (selected) { this.selection.position.copy(toThree(selected, 0.5)); this.selection.scale.setScalar(selected.radius + 6); }
    this.range.position.copy(toThree(hero, 0.3)); this.range.scale.setScalar(ABILITIES.q.range);
    this.range.visible = !art && match.phase !== 'ended';
    this.aimLine.visible = !art && !!this.aim;
    if (this.aim) {
      this.aimLine.geometry.setFromPoints([toThree(hero, 2), toThree(this.aim, 2)]);
    }
    this.clearTransients();
    if (!art) for (const entity of match.entities) if (entity.hp > 0) this.headingHint(entity);
    for (const shot of match.projectiles) {
      const mesh = new Mesh(this.shotGeometry, shot.team === 'blue' ? this.blue : this.red);
      mesh.position.copy(toThree(shot, 16)); this.dynamic.add(mesh);
    }
    for (const wall of match.windWalls) {
      const line = new Line(new BufferGeometry().setFromPoints(wallEnds(wall).map(p => toThree(p, 32))), this.wallMaterial);
      this.transientResources.push(line.geometry); this.dynamic.add(line);
    }
    for (const entity of match.entities) {
      if (!entity.qCast || match.time - entity.qCast.startedAt >= YASUO_Q_CAST_SECONDS) continue;
      const heading = entity.qCast.facing;
      const end = { x: entity.x + Math.cos(heading) * ABILITIES.q.range, y: entity.y + Math.sin(heading) * ABILITIES.q.range };
      const line = new Line(new BufferGeometry().setFromPoints([toThree(entity, 12), toThree(end, 12)]), this.hintMaterial);
      this.transientResources.push(line.geometry); this.dynamic.add(line);
    }
    this.renderer.render(this.scene, this.cameraRig.camera); this.onFrame?.(value);
  }
  private readonly sampleFog = new Fog(0x142330, 5000, 6500);
  private readonly headingGeometry = new ConeGeometry(3, 12, 3);
  private headingHint(entity: Entity): void {
    const arrow = new Mesh(this.headingGeometry, entity.team === 'blue' ? this.blue : this.red);
    arrow.rotation.z = -Math.PI / 2; arrow.rotation.y = -entity.facing;
    arrow.position.copy(toThree({ x: entity.x + Math.cos(entity.facing) * (entity.radius + 6), y: entity.y + Math.sin(entity.facing) * (entity.radius + 6) }, 4));
    this.hints.add(arrow);
  }
  private clearTransients(): void {
    this.dynamic.clear(); this.hints.clear();
    for (const resource of this.transientResources) resource.dispose(); this.transientResources = [];
  }
  private clearActors(): void {
    for (const mesh of this.actors.values()) this.scene.remove(mesh); this.actors.clear(); this.clearTransients();
  }
  dispose(): void {
    if (this.disposed) return; this.disposed = true; this.observer.disconnect(); this.clearActors();
    this.sprites.dispose(); this.environment.dispose();
    // Include resources of removed/shared actors in the same ownership tree.
    const owned = new Group();
    owned.add(new Mesh(this.bodyGeometry, this.blue), new Mesh(this.shotGeometry, this.red), new Mesh(this.headingGeometry, this.blue));
    owned.add(new Line(new BufferGeometry(), this.wallMaterial)); this.scene.add(owned);
    disposeSceneResources(this.scene);
    this.scene.clear(); this.renderer.dispose(); this.renderer.forceContextLoss(); this.renderer.domElement.remove();
  }
}
