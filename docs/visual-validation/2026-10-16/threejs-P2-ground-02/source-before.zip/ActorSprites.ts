import { Group, Mesh, MeshBasicMaterial, NearestFilter, PlaneGeometry, SRGBColorSpace, TextureLoader, type Texture } from 'three';
import type { Entity } from '../game/types';
import { YasuoAnimator, flipYasuoAttack } from '../render/YasuoAnimation';
import { YASUO_TEXTURES } from '../render/YasuoAssets';
import { HERO_VISUAL_SCALE } from '../render/Presentation';
import { MINION_CLIPS, MINION_URLS, MinionAnimator } from '../render/MinionAnimation';
import { UNIT_METRICS } from '../game/UnitMetrics';
import { ThreeCamera, toThree } from './Coordinates';
import { actorEnvironmentTint, contactShadowTexture } from './S01Look';

export function atlasRect(frame: number, cellWidth: number, cellHeight: number, sheetWidth: number, sheetHeight: number) {
  if (!Number.isInteger(frame) || ![cellWidth, cellHeight, sheetWidth, sheetHeight].every(value => Number.isInteger(value) && value > 0)) throw new RangeError('Invalid atlas dimensions');
  const columns = sheetWidth / cellWidth, rows = sheetHeight / cellHeight;
  if (!Number.isInteger(columns) || !Number.isInteger(rows) || frame < 0 || frame >= columns * rows) throw new RangeError('Invalid atlas frame');
  return { left: frame % columns / columns, right: (frame % columns + 1) / columns,
    top: 1 - Math.floor(frame / columns) / rows, bottom: 1 - (Math.floor(frame / columns) + 1) / rows };
}

interface ActorView {
  body: Mesh<PlaneGeometry, MeshBasicMaterial>; shadow: Mesh<PlaneGeometry, MeshBasicMaterial>;
  bar: Group; fill: Mesh<PlaneGeometry, MeshBasicMaterial>; animator: YasuoAnimator;
}

/** Existing pixels and animation times, placed on camera-facing foot-anchored cards. */
export class ActorSprites {
  readonly group = new Group();
  readonly errors: string[] = [];
  private readonly actors = new Map<number, ActorView>();
  private readonly textures = new Map<string, { texture: Texture; ready: boolean }>();
  private readonly loader = new TextureLoader();
  private readonly minions = new MinionAnimator();
  private readonly shadowMap = contactShadowTexture();
  private disposed = false;
  hasVisibleBody(id: number): boolean { return this.actors.get(id)?.body.visible ?? false; }
  update(entities: Entity[], time: number, camera: ThreeCamera): void {
    const active = new Set<number>();
    for (const entity of entities) {
      if (entity.kind === 'tower' || entity.hp <= 0) continue;
      active.add(entity.id);
      let view = this.actors.get(entity.id);
      if (!view) { view = this.create(entity); this.actors.set(entity.id, view); }
      const facing = camera.screenHeading(entity, entity.facing);
      let key: string, url: string, frame: number, width: number, height: number, ax: number, ay: number, scale: number, flip: boolean;
      if (entity.kind === 'hero') {
        const mapped = { ...entity, facing,
          qCast: entity.qCast ? { ...entity.qCast, facing: camera.screenHeading(entity, entity.qCast.facing) } : null,
          eCast: entity.eCast ? { ...entity.eCast, facing: camera.screenHeading(entity, entity.eCast.facing) } : entity.eCast,
          eqCast: entity.eqCast ? { ...entity.eqCast, facing: camera.screenHeading(entity, entity.eqCast.facing) } : entity.eqCast,
        };
        const sample = view.animator.sample(mapped, time), clip = sample.clip;
        const asset = YASUO_TEXTURES.find(asset => asset.clip.key === clip.key);
        if (!asset) { view.body.visible = false; continue; }
        key = clip.key; url = asset.url; frame = sample.frame; width = clip.width; height = clip.height;
        ax = clip.anchor[0] / width; ay = clip.anchor[1] / height; scale = sample.scale * HERO_VISUAL_SCALE;
        flip = (sample.state === 'A' || sample.state === 'B') && flipYasuoAttack(facing);
      } else {
        const pose = this.minions.sample({ ...entity, facing }, time), clip = MINION_CLIPS[pose.key.replace('minion-', '') as keyof typeof MINION_CLIPS];
        key = pose.key; url = Object.entries(MINION_URLS).find(([path]) => path.endsWith(`/${key.replace('minion-', '')}.png`))![1];
        frame = pose.frame; width = clip.width; height = clip.height; ax = pose.originX; ay = pose.originY;
        scale = pose.scale; flip = pose.flip;
      }
      const entry = this.texture(key, url), image = entry.texture.image as HTMLImageElement | undefined;
      view.body.visible = entry.ready;
      if (entry.ready && image) {
        const uv = atlasRect(frame, width, height, image.width, image.height);
        if (view.body.material.map !== entry.texture) { view.body.material.map = entry.texture; view.body.material.needsUpdate = true; }
        // Minion origin already incorporates its mirror anchor in MinionAnimator.
        const anchorX = entity.kind === 'hero' && flip ? 1 - ax : ax;
        const x0 = -anchorX * width * scale, x1 = (1 - anchorX) * width * scale;
        const y0 = -(1 - ay) * height * scale, y1 = ay * height * scale;
        const vertices = view.body.geometry.getAttribute('position');
        vertices.setXYZ(0, x0, y1, 0); vertices.setXYZ(1, x1, y1, 0); vertices.setXYZ(2, x0, y0, 0); vertices.setXYZ(3, x1, y0, 0); vertices.needsUpdate = true;
        const coords = view.body.geometry.getAttribute('uv'), left = flip ? uv.right : uv.left, right = flip ? uv.left : uv.right;
        coords.setXY(0, left, uv.top); coords.setXY(1, right, uv.top); coords.setXY(2, left, uv.bottom); coords.setXY(3, right, uv.bottom); coords.needsUpdate = true;
      }
      const lift = (entity.airborneUntil ?? 0) > time ? 30 : 0;
      view.body.position.copy(toThree(entity, lift + 0.4)); view.body.quaternion.copy(camera.camera.quaternion);
      actorEnvironmentTint(entity, time, entity.team, view.body.material.color);
      view.shadow.position.copy(toThree(entity, 0.2)); view.shadow.material.opacity = lift ? 0.25 : 0.60;
      const spread = lift ? 1.25 : 1;
      view.shadow.scale.set(entity.radius * 4 * spread, entity.radius * 2.4 * spread, 1);
      view.bar.position.copy(toThree(entity, UNIT_METRICS[entity.kind].height + lift + 10)); view.bar.quaternion.copy(camera.camera.quaternion);
      view.fill.scale.x = Math.max(0, entity.hp / entity.maxHp); view.fill.position.x = -15 * (1 - view.fill.scale.x);
    }
    for (const [id, view] of this.actors) if (!active.has(id)) { this.remove(view); this.actors.delete(id); }
    this.minions.retain(active);
  }
  private texture(key: string, url: string) {
    let entry = this.textures.get(key);
    if (!entry) {
      const value = { texture: this.loader.load(url, texture => { if (this.disposed) texture.dispose(); else value.ready = true; }, undefined, () => this.errors.push(key)), ready: false };
      value.texture.colorSpace = SRGBColorSpace; value.texture.magFilter = value.texture.minFilter = NearestFilter;
      value.texture.generateMipmaps = false; this.textures.set(key, value); entry = value;
    } return entry;
  }
  private create(entity: Entity): ActorView {
    const body = new Mesh(new PlaneGeometry(1, 1), new MeshBasicMaterial({ alphaTest: 0.35, toneMapped: false }));
    body.frustumCulled = false; // Atlas frame bounds change during attacks.
    const shadow = new Mesh(new PlaneGeometry(1, 1), new MeshBasicMaterial({ map: this.shadowMap, color: 0x091923, transparent: true, opacity: 0.60, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2;
    const bar = new Group();
    const back = new Mesh(new PlaneGeometry(33, 5), new MeshBasicMaterial({ color: 0x0a121c, depthTest: false, toneMapped: false }));
    const fill = new Mesh(new PlaneGeometry(30, 2), new MeshBasicMaterial({ color: entity.team === 'blue' ? 0x8cc9b5 : 0xc97f7a, depthTest: false, toneMapped: false }));
    back.renderOrder = 100; fill.renderOrder = 101; fill.position.z = 0.01; bar.add(back, fill);
    this.group.add(body, shadow, bar); return { body, shadow, bar, fill, animator: new YasuoAnimator() };
  }
  private remove(view: ActorView): void {
    for (const mesh of [view.body, view.shadow]) { mesh.removeFromParent(); mesh.geometry.dispose(); mesh.material.dispose(); }
    view.bar.traverse(object => { if (object instanceof Mesh) { object.geometry.dispose(); object.material.dispose(); } });
    view.bar.removeFromParent(); view.bar.clear();
  }
  reset(): void { for (const view of this.actors.values()) this.remove(view); this.actors.clear(); this.minions.reset(); }
  dispose(): void {
    if (this.disposed) return; this.disposed = true; this.reset();
    for (const entry of this.textures.values()) entry.texture.dispose(); this.textures.clear();
    this.shadowMap.dispose();
    this.group.removeFromParent();
  }
}
